<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Variáveis para armazenar os dados do formulário
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    // Validação simples dos dados (pode ser expandida conforme necessário)
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $response = array("status" => "error", "message" => "Por favor, preencha todos os campos.");
        echo json_encode($response);
        exit;
    }

    // Validação do e-mail
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response = array("status" => "error", "message" => "Por favor, insira um e-mail válido.");
        echo json_encode($response);
        exit;
    }

    // Configurações de e-mail
    $to = " contato@stgchina.com.br"; // Substitua pelo seu endereço de e-mail
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $email_subject = "Novo contato: " . $subject;
    $email_body = "
        <html>
        <head>
            <title>$subject</title>
        </head>
        <body>
            <p><strong>Nome:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Assunto:</strong> $subject</p>
            <p><strong>Mensagem:</strong></p>
            <p>$message</p>
        </body>
        </html>
    ";

    // Enviar e-mail
    if (mail($to, $email_subject, $email_body, $headers)) {
        $response = array("status" => "success", "message" => "Mensagem enviada com sucesso!");
    } else {
        $response = array("status" => "error", "message" => "Erro ao enviar mensagem. Tente novamente mais tarde.");
    }

    echo json_encode($response);
}
?>
